# EDA 04 Homework

#### CST53 HeQi 2015011299

## input.txt

line 1: Integer n, m. n = The number of total ops. m = The number of types of ops.

line 2: n Integers, each in range [1,m], describes the type of the op.

line 3: m Integers, describes the restriction of each type of op within a single stage.

line 4~n+3: n lines, each line contains the predecessor of the current op. Each line ends with a single zero.

NOTICE: Index begin from 1.

## output\_\*.txt

line 1: Integer k, the number of stages.

line 2~k+1: The ops needs to perform in each stage.

NOTICE: Index begin from 1.
